from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.views.generic.list import ListView
import os
import subprocess
def verContenido(ruta):
	ls = str(subprocess.check_output("ls -l " + ruta, shell = True))
	ls = ls.split('\\')
	aux = []
	l = []
	s=[]
	for elemento in ls[1:len(ls)-1]:
		aux = elemento.split(' ')
		aux = [x for x in aux if x]
		aux.pop(1)
		s.append((aux[0])[1])
		l.append(aux[7])

	return l,s

def index (request):
	ruta="/home/juan/myproject/gestorarchivos/entorno"
	lis, tipos=verContenido(ruta)
	lista=zip(lis,tipos)
	return render(request,'plantilla/home.html',{'lista':lista,'ruta_actual':ruta})

def verCarpeta(request,nombre,ruta_actual):
	carpeta_actual=nombre
	ruta_act = ruta_actual

	rut=ruta_act+"/"+carpeta_actual
	lis, tipos =verContenido(ruta)
	lista=zip(lis,tipos)
	return HttpResponse("ESTO ENTRA"+ruta_actual+carpeta_actual)
	#return render(request,'plantilla/home.html',{'lista':lista,'ruta_actual':rut})




def crear_archivo (request):
    return render(request,'plantilla/crearArchivo.html')
def crear_carpeta(request):
    return HttpResponse("aqui es donde se va crear el carpeta")
# Create your views here.

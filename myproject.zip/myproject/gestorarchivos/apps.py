from django.apps import AppConfig


class GestorarchivosConfig(AppConfig):
    name = 'gestorarchivos'

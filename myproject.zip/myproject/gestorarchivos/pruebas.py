import os
import subprocess

def verContenido(ruta):
    ls = str(subprocess.check_output("ls -l " + ruta, shell = True))
    ls = ls.split('\\')
    aux = []
    l = []
    s=[]
    for elemento in ls[1:len(ls)-1]:
        aux = elemento.split(' ')
        aux = [x for x in aux if x]
        aux.pop(1)
        s.append((aux[0])[0])
        l.append({
            'permisos': aux[0],
            'usuario': aux[1],
            'grupo': aux[2],
            'peso': aux[3],
            'fecha': aux[4] + " "+ aux[5] + " " + aux[6],
            'nombre': aux[7]})
    return l,s
l,s=verContenido("/home/juan/myproject/gestorarchivos/entorno")
for l,s in zip(l,s):
    print (l)
    print(s)


